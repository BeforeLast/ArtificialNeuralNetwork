# ImageDirectoryIterator Constants
IMAGEDIRECTORYITERATOR_CONST = {
    'zero_padding':{
        'l': 0,
        'rgb': (0,0,0),
        'rgba': (0,0,0,0)
    }
}